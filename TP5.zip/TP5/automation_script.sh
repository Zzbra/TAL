#!/bin/bash
val=150
python3 Q3.py "corpus.train.txt" "corpus_prep.data" "patron.train.txt" $val
python3 Q3.py "corpus.dev.txt" "corpus_prep.dev" "patron.train.txt" $val
python3 Q3.py "corpus.test.txt" "corpus_prep.test" "patron.train.txt" $val
